# bili_icon_pack
direct extracted from bilibili webpage

svg file in pic folder
